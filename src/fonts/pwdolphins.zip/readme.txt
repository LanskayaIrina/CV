This font was created by : www.peax-webdesign.com
----------------------------------------------------
You can use it for free only for your personal projects. 
For commercial use, you have to donate any amount you wish
to paypal id : michel.lun@free.fr 
----------------------------------------------------

Follow me on Facebook /fr-fr.facebook.com/peax.webdesign 
and G+ plus.google.com/103595703505477716588 
for news about future fonts.